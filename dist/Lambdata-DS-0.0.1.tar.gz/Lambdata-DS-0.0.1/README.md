# Lambdata-DS
Collection of DS


## Installation

TODO

## USAGE

TODO

'''
from my_lambdata.ds_utilities import enlarge

print(enlarge(5))
'''