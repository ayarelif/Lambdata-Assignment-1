def enlarge(n):
    """
    Param n is a number
    Function will enlarge the number
    """
    return n * 100

if __name__=="__main__":
    print(enlarge(5))
