from my_lambdata.ds_utilities import enlarge

print(enlarge(5))